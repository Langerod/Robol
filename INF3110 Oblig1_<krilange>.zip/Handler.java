public interface Handler{
    void interpret();
}
